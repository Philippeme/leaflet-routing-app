// Énumération des types de processus
export enum ProcessType {
    BIRTH = 'BIRTH',
    MARRIAGE = 'MARRIAGE',
    DEATH = 'DEATH'
}

// Énumération des états d'étape
export enum StepStatus {
    NOT_STARTED = 'NOT_STARTED',
    IN_PROGRESS = 'IN_PROGRESS',
    COMPLETED = 'COMPLETED',
    BLOCKED = 'BLOCKED',
    CANCELLED = 'CANCELLED'
}

// Interface pour une étape du processus
export interface ProcessStep {
    id: string;
    order: number;
    label: string;
    icon: string;
    status: StepStatus;
    completionDate?: Date;
}

// Interface pour un processus complet
export interface Process {
    id: string;
    type: ProcessType;
    declarationNumber: string;
    nina: string;
    steps: ProcessStep[];
    createdAt: Date;
    updatedAt: Date;
}

// Interface pour un état de la timeline
export interface TimelineState {
    processes: Process[];
    selectedProcess?: Process;
}