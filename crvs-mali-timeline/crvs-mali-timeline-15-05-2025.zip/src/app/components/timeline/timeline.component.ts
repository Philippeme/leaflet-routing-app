import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Process, ProcessStep, StepStatus } from '../../models';
import { ProcessService } from '../../services/process.service';
import { StepDialogComponent } from '../step-dialog/step-dialog.component';

@Component({
    selector: 'app-timeline',
    templateUrl: './timeline.component.html',
    styleUrls: ['./timeline.component.scss']
})
export class TimelineComponent implements OnInit, OnChanges {
    @Input() process!: Process;
    steps: ProcessStep[] = [];

    // Exposer l'énumération StepStatus au template
    stepStatus = StepStatus;

    constructor(
        private processService: ProcessService,
        private dialog: MatDialog
    ) { }

    ngOnInit(): void {
        if (this.process) {
            this.steps = [...this.process.steps].sort((a, b) => a.order - b.order);
        }
    }

    ngOnChanges(changes: SimpleChanges): void {
        if (changes['process'] && this.process) {
            this.steps = [...this.process.steps].sort((a, b) => a.order - b.order);
        }
    }

    // Ouvrir le dialogue de modification d'étape
    openStepDialog(step: ProcessStep): void {
        const dialogRef = this.dialog.open(StepDialogComponent, {
            width: '400px',
            data: {
                step,
                process: this.process
            }
        });

        dialogRef.afterClosed().subscribe(result => {
            if (result) {
                this.processService.updateStepStatus(this.process.id, step.id, result.status);
            }
        });
    }

    // Obtenir les classes CSS pour le nœud d'étape
    getStepNodeClassMap(step: ProcessStep): { [key: string]: boolean } {
        const classMap: { [key: string]: boolean } = {};

        switch (step.status) {
            case StepStatus.COMPLETED:
                classMap['green'] = true;
                break;
            case StepStatus.IN_PROGRESS:
                classMap['orange'] = true;
                break;
            case StepStatus.BLOCKED:
            case StepStatus.CANCELLED:
                classMap['red'] = true;
                break;
            default:
                classMap['gray'] = true;
                break;
        }

        // Ajouter la classe clickable si l'étape est cliquable
        if (this.isStepClickable(step)) {
            classMap['clickable'] = true;
        }

        return classMap;
    }

    // Obtenir la classe CSS pour la ligne de connexion entre deux jalons
    getConnectionLineClass(index: number): string {
        if (index >= this.steps.length - 1) {
            return '';
        }

        const currentStep = this.steps[index];
        const nextStep = this.steps[index + 1];

        // Implémentation des règles du client pour les couleurs de la barre de progression
        if (currentStep.status === StepStatus.COMPLETED) {
            // Si l'étape actuelle est complétée, la ligne jusqu'à la prochaine est verte
            return 'green-line';
        } else if (currentStep.status === StepStatus.IN_PROGRESS) {
            // Si l'étape actuelle est en cours, la ligne vers la prochaine est orange
            return 'orange-line';
        } else if (currentStep.status === StepStatus.BLOCKED || currentStep.status === StepStatus.CANCELLED) {
            // Si l'étape actuelle est bloquée ou annulée, la ligne vers la prochaine est rouge
            return 'red-line';
        } else {
            // Par défaut, la ligne est grise
            return 'gray-line';
        }
    }

    // Déterminer l'icône à afficher en fonction du statut de l'étape
    getStepStatusIcon(step: ProcessStep): string {
        switch (step.status) {
            case StepStatus.COMPLETED:
                return 'check'; // Coche pour l'état Fait
            case StepStatus.IN_PROGRESS:
                return 'more_horiz'; // Points de suspension pour l'état En cours
            case StepStatus.BLOCKED:
            case StepStatus.CANCELLED:
                return 'close'; // Croix pour les états Bloqué ou Annulé
            default:
                return '';
        }
    }

    // Vérifier si une étape est cliquable
    isStepClickable(step: ProcessStep): boolean {
        const index = this.steps.findIndex(s => s.id === step.id);
        if (index === 0) return true; // La première étape est toujours cliquable

        // Une étape est cliquable uniquement si toutes les étapes précédentes sont complétées
        for (let i = 0; i < index; i++) {
            if (this.steps[i].status !== StepStatus.COMPLETED) {
                return false;
            }
        }

        return true;
    }
}