import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Process, ProcessStep, StepStatus } from '../../models';

interface DialogData {
    step: ProcessStep;
    process: Process;
}

@Component({
    selector: 'app-step-dialog',
    templateUrl: './step-dialog.component.html',
    styleUrls: ['./step-dialog.component.scss']
})
export class StepDialogComponent implements OnInit {
    step: ProcessStep;
    process: Process;
    selectedStatus: StepStatus;

    // Exposer l'énumération StepStatus au template
    stepStatusEnum = StepStatus;

    // Options de statut disponibles pour l'étape
    statusOptions = [
        { value: StepStatus.COMPLETED, label: 'Fait', icon: 'check_circle' },
        { value: StepStatus.IN_PROGRESS, label: 'En cours', icon: 'pending' },
        { value: StepStatus.BLOCKED, label: 'Bloqué', icon: 'block' },
        { value: StepStatus.CANCELLED, label: 'Annulé', icon: 'cancel' }
    ];

    constructor(
        public dialogRef: MatDialogRef<StepDialogComponent>,
        @Inject(MAT_DIALOG_DATA) public data: DialogData
    ) {
        this.step = data.step;
        this.process = data.process;
        this.selectedStatus = this.step.status;
    }

    ngOnInit(): void {
    }

    // Fermer le dialogue sans appliquer les modifications
    onCancel(): void {
        this.dialogRef.close();
    }

    // Valider les modifications et fermer le dialogue
    onSave(): void {
        // Retourner le nouveau statut
        this.dialogRef.close({
            status: this.selectedStatus
        });
    }

    // Récupérer le libellé du statut
    getStatusLabel(status: StepStatus): string {
        const option = this.statusOptions.find(opt => opt.value === status);
        return option ? option.label : '';
    }

    // Récupérer l'icône du statut
    getStatusIcon(status: StepStatus): string {
        const option = this.statusOptions.find(opt => opt.value === status);
        return option ? option.icon : '';
    }

    // Générer les classes pour une option de statut
    getOptionClassMap(optionValue: StepStatus): { [key: string]: boolean } {
        const classMap: { [key: string]: boolean } = {
            'selected': this.selectedStatus === optionValue
        };

        // Ajouter la classe appropriée en fonction du statut
        switch (optionValue) {
            case StepStatus.COMPLETED:
                classMap['status-completed'] = true;
                break;
            case StepStatus.IN_PROGRESS:
                classMap['status-in-progress'] = true;
                break;
            case StepStatus.BLOCKED:
                classMap['status-blocked'] = true;
                break;
            case StepStatus.CANCELLED:
                classMap['status-cancelled'] = true;
                break;
        }

        return classMap;
    }
}