import { Component, Input, OnInit } from '@angular/core';
import { Process, ProcessType } from '../../models';

@Component({
    selector: 'app-process-banner',
    templateUrl: './process-banner.component.html',
    styleUrls: ['./process-banner.component.scss']
})
export class ProcessBannerComponent implements OnInit {
    @Input() process!: Process;

    constructor() { }

    ngOnInit(): void {
    }

    // Obtenir le titre du processus en fonction du type
    getProcessTitle(): string {
        switch (this.process.type) {
            case ProcessType.BIRTH:
                return 'Acte de Naissance';
            case ProcessType.MARRIAGE:
                return 'Acte de Mariage';
            case ProcessType.DEATH:
                return 'Acte de Décès';
            default:
                return '';
        }
    }

    // Formater le NINA pour l'affichage visuel
    formatNina(nina: string): string[] {
        return nina.split('');
    }

    // Obtenir les classes CSS pour la bannière
    getBannerClassMap(): { [key: string]: boolean } {
        const classMap: { [key: string]: boolean } = {};

        switch (this.process.type) {
            case ProcessType.BIRTH:
                classMap['birth-banner'] = true;
                break;
            case ProcessType.MARRIAGE:
                classMap['marriage-banner'] = true;
                break;
            case ProcessType.DEATH:
                classMap['death-banner'] = true;
                break;
        }

        return classMap;
    }
}