import { Component, Input, OnInit } from '@angular/core';
import { Process, ProcessType, StepStatus } from '../../models';

@Component({
    selector: 'app-process-card',
    templateUrl: './process-card.component.html',
    styleUrls: ['./process-card.component.scss']
})
export class ProcessCardComponent implements OnInit {
    @Input() process!: Process;
    @Input() isSelected: boolean = false;

    completedSteps: number = 0;
    totalSteps: number = 0;
    progressPercentage: number = 0;
    currentStatus: string = '';

    constructor() { }

    ngOnInit(): void {
        this.calculateProgress();
    }

    calculateProgress(): void {
        this.totalSteps = this.process.steps.length;
        this.completedSteps = this.process.steps.filter(step => step.status === StepStatus.COMPLETED).length;
        this.progressPercentage = (this.completedSteps / this.totalSteps) * 100;

        // Déterminer le statut actuel du processus
        if (this.process.steps.some(step => step.status === StepStatus.BLOCKED || step.status === StepStatus.CANCELLED)) {
            this.currentStatus = 'Bloqué';
        } else if (this.progressPercentage === 100) {
            this.currentStatus = 'Terminé';
        } else if (this.progressPercentage === 0) {
            this.currentStatus = 'Pas commencé';
        } else {
            this.currentStatus = 'En cours';
        }
    }

    // Obtenir l'icône en fonction du type de processus
    getProcessIcon(): string {
        switch (this.process.type) {
            case ProcessType.BIRTH:
                return 'child_care';
            case ProcessType.MARRIAGE:
                return 'favorite';
            case ProcessType.DEATH:
                return 'contact_emergency';
            default:
                return 'description';
        }
    }

    // Obtenir les classes CSS pour la carte
    getClassMap(): { [key: string]: boolean } {
        const classMap: { [key: string]: boolean } = {
            'selected': this.isSelected
        };

        // Ajouter la classe en fonction du type
        switch (this.process.type) {
            case ProcessType.BIRTH:
                classMap['birth-card'] = true;
                break;
            case ProcessType.MARRIAGE:
                classMap['marriage-card'] = true;
                break;
            case ProcessType.DEATH:
                classMap['death-card'] = true;
                break;
        }

        return classMap;
    }

    // Obtenir les classes CSS pour le statut
    getStatusClassMap(): { [key: string]: boolean } {
        const classMap: { [key: string]: boolean } = {};

        switch (this.currentStatus) {
            case 'Terminé':
                classMap['status-completed'] = true;
                break;
            case 'En cours':
                classMap['status-in-progress'] = true;
                break;
            case 'Bloqué':
                classMap['status-blocked'] = true;
                break;
            default:
                classMap['status-not-started'] = true;
                break;
        }

        return classMap;
    }
}