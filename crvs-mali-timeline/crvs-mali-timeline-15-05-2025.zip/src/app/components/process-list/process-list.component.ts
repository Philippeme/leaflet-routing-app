import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { Process, ProcessType } from '../../models';
import { ProcessService } from '../../services/process.service';

@Component({
    selector: 'app-process-list',
    templateUrl: './process-list.component.html',
    styleUrls: ['./process-list.component.scss']
})
export class ProcessListComponent implements OnInit, OnChanges {
    @Input() processType!: ProcessType;

    processes: Process[] = [];
    selectedProcess?: Process;

    constructor(private processService: ProcessService) { }

    ngOnInit(): void {
        this.loadProcesses();

        // S'abonner aux changements de processus
        this.processService.getProcesses().subscribe(processes => {
            this.filterProcesses(processes);
        });

        // S'abonner au processus sélectionné
        this.processService.getSelectedProcess().subscribe(process => {
            this.selectedProcess = process;
        });
    }

    ngOnChanges(changes: SimpleChanges): void {
        if (changes['processType']) {
            this.loadProcesses();
            this.processService.selectProcess(undefined); // Désélectionner le processus actuel
        }
    }

    loadProcesses(): void {
        this.processService.getProcesses().subscribe(processes => {
            this.filterProcesses(processes);
        });
    }

    filterProcesses(processes: Process[]): void {
        this.processes = processes.filter(p => p.type === this.processType)
            .sort((a, b) => b.updatedAt.getTime() - a.updatedAt.getTime()); // Tri par date de mise à jour
    }

    selectProcess(process: Process): void {
        this.processService.selectProcess(process);
    }

    createNewProcess(): void {
        const newProcess = this.processService.createNewProcess(this.processType);
        this.processService.selectProcess(newProcess);
    }

    getProcessTypeName(): string {
        switch (this.processType) {
            case ProcessType.BIRTH:
                return 'Acte de Naissance';
            case ProcessType.MARRIAGE:
                return 'Acte de Mariage';
            case ProcessType.DEATH:
                return 'Acte de Décès';
            default:
                return '';
        }
    }
}