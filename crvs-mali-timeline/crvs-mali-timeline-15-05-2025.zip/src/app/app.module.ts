import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

// Modules Angular Material
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatTabsModule } from '@angular/material/tabs';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSelectModule } from '@angular/material/select';
import { MatDialogModule } from '@angular/material/dialog';
import { MatDividerModule } from '@angular/material/divider';

// Composants de l'application
import { AppComponent } from './app.component';
import { ProcessListComponent } from './components/process-list/process-list.component';
import { TimelineComponent } from './components/timeline/timeline.component';
import { ProcessBannerComponent } from './components/process-banner/process-banner.component';
import { ProcessCardComponent } from './components/process-card/process-card.component';
import { StepDialogComponent } from './components/step-dialog/step-dialog.component';

@NgModule({
  declarations: [
    AppComponent,
    ProcessListComponent,
    TimelineComponent,
    ProcessBannerComponent,
    ProcessCardComponent,
    StepDialogComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatCardModule,
    MatIconModule,
    MatTabsModule,
    MatToolbarModule,
    MatSelectModule,
    MatDialogModule,
    MatDividerModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }