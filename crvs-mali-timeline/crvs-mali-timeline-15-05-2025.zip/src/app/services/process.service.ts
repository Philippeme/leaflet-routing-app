import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { Process, ProcessStep, ProcessType, StepStatus } from '../models';

@Injectable({
    providedIn: 'root'
})
export class ProcessService {

naissances: any =  [
            {
                id: 'b1-001',
                order: 1,
                label: 'Enregistrement de naissance',
                icon: 'app_registration',
                status: true,
                isRejected: false,
                completionDate: '2025-04-15'
            },
            {
                id: 'b2-001',
                order: 2,
                label: 'Déclaration de naissance',
                icon: 'description',
                status: true,
                isRejected: false,
                completionDate: '2025-04-18'
            },
            {
                id: 'b3-001',
                order: 3,
                label: 'Établissement de l\'acte',
                icon: 'gavel',
                status: false,
                isRejected: false,
                completionDate: null
            },
            {
                id: 'b4-001',
                order: 4,
                label: 'Remise de l\'acte',
                icon: 'assignment_turned_in',
                status: false,
                isRejected: false,
                completionDate: null
            }
        ];

mariages: any =  [
                {
                    id: 'm1-001',
                    order: 1,
                    label: 'Déclaration de mariage',
                    icon: 'favorite',
                    status: true,
                    isRejected: false,
                    completionDate: '2025-04-10'
                },
                {
                    id: 'm2-001',
                    order: 2,
                    label: 'Publication de mariage',
                    icon: 'campaign',
                    status: true,
                    isRejected: false,
                    completionDate: '2025-04-17'
                },
                {
                    id: 'm3-001',
                    order: 3,
                    label: 'Enquêtes prénuptiales',
                    icon: 'find_in_page',
                    status: false,
                    isRejected: true,
                    completionDate: null
                },
                {
                    id: 'm4-001',
                    order: 4,
                    label: 'Célébration et Remise de l\'acte',
                    icon: 'celebration',
                    status: false,
                    isRejected: false,
                    completionDate: null
                }
            ];

deces: any = [
                {
                    id: 'd1-001',
                    order: 1,
                    label: 'Certificat de décès',
                    icon: 'medical_services',
                    status: true,
                    isRejected: false,
                    completionDate: '2025-04-12'
                },
                {
                    id: 'd2-001',
                    order: 2,
                    label: 'Déclaration de décès',
                    icon: 'description',
                    status: true,
                    isRejected: false,
                    completionDate: '2025-04-14'
                },
                {
                    id: 'd3-001',
                    order: 3,
                    label: 'Établissement de l\'acte',
                    icon: 'gavel',
                    status: true,
                    isRejected: false,
                    completionDate: '2025-04-20'
                },
                {
                    id: 'd4-001',
                    order: 4,
                    label: 'Remise de l\'acte',
                    icon: 'assignment_turned_in',
                    status: false,
                    isRejected: false,
                    completionDate: null
                }
            ];



    // Base de données JSON complète pour tous les processus et leurs variations d'état
     mockData: Process[] = [
        // === PROCESSUS D'ACTES DE NAISSANCE ===
        {
            id: 'birth-001',
            type: ProcessType.BIRTH,
            declarationNumber: 'N-2025-0001',
            nina: '123456789012345',
            steps: [
                {
                    id: 'b1-001',
                    order: 1,
                    label: 'Enregistrement de naissance',
                    icon: 'app_registration',
                    status: StepStatus.COMPLETED,
                    completionDate: new Date('2025-04-15')
                },
                {
                    id: 'b2-001',
                    order: 2,
                    label: 'Déclaration de naissance',
                    icon: 'description',
                    status: StepStatus.COMPLETED,
                    completionDate: new Date('2025-04-18')
                },
                {
                    id: 'b3-001',
                    order: 3,
                    label: 'Établissement de l\'acte',
                    icon: 'gavel',
                    status: StepStatus.IN_PROGRESS,
                    completionDate: undefined
                },
                {
                    id: 'b4-001',
                    order: 4,
                    label: 'Remise de l\'acte',
                    icon: 'assignment_turned_in',
                    status: StepStatus.NOT_STARTED,
                    completionDate: undefined
                }
            ],
            createdAt: new Date('2025-04-10'),
            updatedAt: new Date('2025-04-18')
        },
        {
            id: 'birth-002',
            type: ProcessType.BIRTH,
            declarationNumber: 'N-2025-0002',
            nina: '234567890123456',
            steps: [
                {
                    id: 'b1-002',
                    order: 1,
                    label: 'Enregistrement de naissance',
                    icon: 'app_registration',
                    status: StepStatus.COMPLETED, // NOT_STARTED, IN_PROGRESS, COMPLETED, BLOCKED, CANCELLED
                    completionDate: new Date('2025-04-12')
                },
                {
                    id: 'b2-002',
                    order: 2,
                    label: 'Déclaration de naissance',
                    icon: 'description',
                    status: StepStatus.COMPLETED,
                    completionDate: new Date('2025-04-20')
                },
                {
                    id: 'b3-002',
                    order: 3,
                    label: 'Établissement de l\'acte',
                    icon: 'gavel',
                    status: StepStatus.COMPLETED,
                    completionDate: new Date('2025-04-25')
                },
                {
                    id: 'b4-002',
                    order: 4,
                    label: 'Remise de l\'acte',
                    icon: 'assignment_turned_in',
                    status: StepStatus.IN_PROGRESS,
                    completionDate: undefined
                }
            ],
            createdAt: new Date('2025-04-08'),
            updatedAt: new Date('2025-04-25')
        },
        {
            id: 'birth-003',
            type: ProcessType.BIRTH,
            declarationNumber: 'N-2025-0003',
            nina: '345678901234567',
            steps: [
                {
                    id: 'b1-003',
                    order: 1,
                    label: 'Enregistrement de naissance',
                    icon: 'app_registration',
                    status: StepStatus.COMPLETED,
                    completionDate: new Date('2025-04-05')
                },
                {
                    id: 'b2-003',
                    order: 2,
                    label: 'Déclaration de naissance',
                    icon: 'description',
                    status: StepStatus.BLOCKED,
                    completionDate: undefined
                },
                {
                    id: 'b3-003',
                    order: 3,
                    label: 'Établissement de l\'acte',
                    icon: 'gavel',
                    status: StepStatus.BLOCKED,
                    completionDate: undefined
                },
                {
                    id: 'b4-003',
                    order: 4,
                    label: 'Remise de l\'acte',
                    icon: 'assignment_turned_in',
                    status: StepStatus.BLOCKED,
                    completionDate: undefined
                }
            ],
            createdAt: new Date('2025-04-02'),
            updatedAt: new Date('2025-04-05')
        },
        {
            id: 'birth-004',
            type: ProcessType.BIRTH,
            declarationNumber: 'N-2025-0004',
            nina: '456789012345678',
            steps: [
                {
                    id: 'b1-004',
                    order: 1,
                    label: 'Enregistrement de naissance',
                    icon: 'app_registration',
                    status: StepStatus.NOT_STARTED,
                    completionDate: undefined
                },
                {
                    id: 'b2-004',
                    order: 2,
                    label: 'Déclaration de naissance',
                    icon: 'description',
                    status: StepStatus.NOT_STARTED,
                    completionDate: undefined
                },
                {
                    id: 'b3-004',
                    order: 3,
                    label: 'Établissement de l\'acte',
                    icon: 'gavel',
                    status: StepStatus.NOT_STARTED,
                    completionDate: undefined
                },
                {
                    id: 'b4-004',
                    order: 4,
                    label: 'Remise de l\'acte',
                    icon: 'assignment_turned_in',
                    status: StepStatus.NOT_STARTED,
                    completionDate: undefined
                }
            ],
            createdAt: new Date('2025-05-01'),
            updatedAt: new Date('2025-05-01')
        },

        // === PROCESSUS D'ACTES DE MARIAGE ===
        {
            id: 'marriage-001',
            type: ProcessType.MARRIAGE,
            declarationNumber: 'M-2025-0001',
            nina: '987654321098765',
            steps: [
                {
                    id: 'm1-001',
                    order: 1,
                    label: 'Déclaration de mariage',
                    icon: 'favorite',
                    status: StepStatus.COMPLETED,
                    completionDate: new Date('2025-04-10')
                },
                {
                    id: 'm2-001',
                    order: 2,
                    label: 'Publication de mariage',
                    icon: 'campaign',
                    status: StepStatus.COMPLETED,
                    completionDate: new Date('2025-04-17')
                },
                {
                    id: 'm3-001',
                    order: 3,
                    label: 'Enquêtes prénuptiales',
                    icon: 'find_in_page',
                    status: StepStatus.BLOCKED,
                    completionDate: undefined
                },
                {
                    id: 'm4-001',
                    order: 4,
                    label: 'Célébration et Remise de l\'acte',
                    icon: 'celebration',
                    status: StepStatus.BLOCKED,
                    completionDate: undefined
                }
            ],
            createdAt: new Date('2025-04-05'),
            updatedAt: new Date('2025-04-17')
        },
        {
            id: 'marriage-002',
            type: ProcessType.MARRIAGE,
            declarationNumber: 'M-2025-0002',
            nina: '876543210987654',
            steps: [
                {
                    id: 'm1-002',
                    order: 1,
                    label: 'Déclaration de mariage',
                    icon: 'favorite',
                    status: StepStatus.COMPLETED,
                    completionDate: new Date('2025-04-01')
                },
                {
                    id: 'm2-002',
                    order: 2,
                    label: 'Publication de mariage',
                    icon: 'campaign',
                    status: StepStatus.COMPLETED,
                    completionDate: new Date('2025-04-08')
                },
                {
                    id: 'm3-002',
                    order: 3,
                    label: 'Enquêtes prénuptiales',
                    icon: 'find_in_page',
                    status: StepStatus.COMPLETED,
                    completionDate: new Date('2025-04-22')
                },
                {
                    id: 'm4-002',
                    order: 4,
                    label: 'Célébration et Remise de l\'acte',
                    icon: 'celebration',
                    status: StepStatus.IN_PROGRESS,
                    completionDate: undefined
                }
            ],
            createdAt: new Date('2025-03-25'),
            updatedAt: new Date('2025-04-22')
        },
        {
            id: 'marriage-003',
            type: ProcessType.MARRIAGE,
            declarationNumber: 'M-2025-0003',
            nina: '765432109876543',
            steps: [
                {
                    id: 'm1-003',
                    order: 1,
                    label: 'Déclaration de mariage',
                    icon: 'favorite',
                    status: StepStatus.COMPLETED,
                    completionDate: new Date('2025-03-15')
                },
                {
                    id: 'm2-003',
                    order: 2,
                    label: 'Publication de mariage',
                    icon: 'campaign',
                    status: StepStatus.COMPLETED,
                    completionDate: new Date('2025-03-22')
                },
                {
                    id: 'm3-003',
                    order: 3,
                    label: 'Enquêtes prénuptiales',
                    icon: 'find_in_page',
                    status: StepStatus.COMPLETED,
                    completionDate: new Date('2025-04-05')
                },
                {
                    id: 'm4-003',
                    order: 4,
                    label: 'Célébration et Remise de l\'acte',
                    icon: 'celebration',
                    status: StepStatus.COMPLETED,
                    completionDate: new Date('2025-04-12')
                }
            ],
            createdAt: new Date('2025-03-10'),
            updatedAt: new Date('2025-04-12')
        },
        {
            id: 'marriage-004',
            type: ProcessType.MARRIAGE,
            declarationNumber: 'M-2025-0004',
            nina: '654321098765432',
            steps: [
                {
                    id: 'm1-004',
                    order: 1,
                    label: 'Déclaration de mariage',
                    icon: 'favorite',
                    status: StepStatus.IN_PROGRESS,
                    completionDate: undefined
                },
                {
                    id: 'm2-004',
                    order: 2,
                    label: 'Publication de mariage',
                    icon: 'campaign',
                    status: StepStatus.NOT_STARTED,
                    completionDate: undefined
                },
                {
                    id: 'm3-004',
                    order: 3,
                    label: 'Enquêtes prénuptiales',
                    icon: 'find_in_page',
                    status: StepStatus.NOT_STARTED,
                    completionDate: undefined
                },
                {
                    id: 'm4-004',
                    order: 4,
                    label: 'Célébration et Remise de l\'acte',
                    icon: 'celebration',
                    status: StepStatus.NOT_STARTED,
                    completionDate: undefined
                }
            ],
            createdAt: new Date('2025-05-02'),
            updatedAt: new Date('2025-05-02')
        },

        // === PROCESSUS D'ACTES DE DÉCÈS ===
        {
            id: 'death-001',
            type: ProcessType.DEATH,
            declarationNumber: 'D-2025-0001',
            nina: '456789012345678',
            steps: [
                {
                    id: 'd1-001',
                    order: 1,
                    label: 'Certificat de décès',
                    icon: 'medical_services',
                    status: StepStatus.COMPLETED,
                    completionDate: new Date('2025-04-12')
                },
                {
                    id: 'd2-001',
                    order: 2,
                    label: 'Déclaration de décès',
                    icon: 'description',
                    status: StepStatus.COMPLETED,
                    completionDate: new Date('2025-04-14')
                },
                {
                    id: 'd3-001',
                    order: 3,
                    label: 'Établissement de l\'acte',
                    icon: 'gavel',
                    status: StepStatus.COMPLETED,
                    completionDate: new Date('2025-04-20')
                },
                {
                    id: 'd4-001',
                    order: 4,
                    label: 'Remise de l\'acte',
                    icon: 'assignment_turned_in',
                    status: StepStatus.IN_PROGRESS,
                    completionDate: undefined
                }
            ],
            createdAt: new Date('2025-04-10'),
            updatedAt: new Date('2025-04-20')
        },
        {
            id: 'death-002',
            type: ProcessType.DEATH,
            declarationNumber: 'D-2025-0002',
            nina: '567890123456789',
            steps: [
                {
                    id: 'd1-002',
                    order: 1,
                    label: 'Certificat de décès',
                    icon: 'medical_services',
                    status: StepStatus.COMPLETED,
                    completionDate: new Date('2025-04-01')
                },
                {
                    id: 'd2-002',
                    order: 2,
                    label: 'Déclaration de décès',
                    icon: 'description',
                    status: StepStatus.COMPLETED,
                    completionDate: new Date('2025-04-03')
                },
                {
                    id: 'd3-002',
                    order: 3,
                    label: 'Établissement de l\'acte',
                    icon: 'gavel',
                    status: StepStatus.COMPLETED,
                    completionDate: new Date('2025-04-10')
                },
                {
                    id: 'd4-002',
                    order: 4,
                    label: 'Remise de l\'acte',
                    icon: 'assignment_turned_in',
                    status: StepStatus.COMPLETED,
                    completionDate: new Date('2025-04-15')
                }
            ],
            createdAt: new Date('2025-03-28'),
            updatedAt: new Date('2025-04-15')
        },
        {
            id: 'death-003',
            type: ProcessType.DEATH,
            declarationNumber: 'D-2025-0003',
            nina: '678901234567890',
            steps: [
                {
                    id: 'd1-003',
                    order: 1,
                    label: 'Certificat de décès',
                    icon: 'medical_services',
                    status: StepStatus.COMPLETED,
                    completionDate: new Date('2025-04-05')
                },
                {
                    id: 'd2-003',
                    order: 2,
                    label: 'Déclaration de décès',
                    icon: 'description',
                    status: StepStatus.CANCELLED,
                    completionDate: undefined
                },
                {
                    id: 'd3-003',
                    order: 3,
                    label: 'Établissement de l\'acte',
                    icon: 'gavel',
                    status: StepStatus.BLOCKED,
                    completionDate: undefined
                },
                {
                    id: 'd4-003',
                    order: 4,
                    label: 'Remise de l\'acte',
                    icon: 'assignment_turned_in',
                    status: StepStatus.BLOCKED,
                    completionDate: undefined
                }
            ],
            createdAt: new Date('2025-04-02'),
            updatedAt: new Date('2025-04-06')
        },
        {
            id: 'death-004',
            type: ProcessType.DEATH,
            declarationNumber: 'D-2025-0004',
            nina: '789012345678901',
            steps: [
                {
                    id: 'd1-004',
                    order: 1,
                    label: 'Certificat de décès',
                    icon: 'medical_services',
                    status: StepStatus.COMPLETED,
                    completionDate: new Date('2025-05-01')
                },
                {
                    id: 'd2-004',
                    order: 2,
                    label: 'Déclaration de décès',
                    icon: 'description',
                    status: StepStatus.IN_PROGRESS,
                    completionDate: undefined
                },
                {
                    id: 'd3-004',
                    order: 3,
                    label: 'Établissement de l\'acte',
                    icon: 'gavel',
                    status: StepStatus.NOT_STARTED,
                    completionDate: undefined
                },
                {
                    id: 'd4-004',
                    order: 4,
                    label: 'Remise de l\'acte',
                    icon: 'assignment_turned_in',
                    status: StepStatus.NOT_STARTED,
                    completionDate: undefined
                }
            ],
            createdAt: new Date('2025-04-28'),
            updatedAt: new Date('2025-05-01')
        }
    ];

    // Réacteurs pour les observables
    private processesSubject = new BehaviorSubject<Process[]>(this.mockData);
    private selectedProcessSubject = new BehaviorSubject<Process | undefined>(undefined);

    // Compteurs pour la génération de nouveaux processus
    private processCounters = {
        [ProcessType.BIRTH]: 4,
        [ProcessType.MARRIAGE]: 4,
        [ProcessType.DEATH]: 4
    };

    constructor() { }

    // === MÉTHODES D'ACCÈS AUX DONNÉES ===

    /**
     * Récupère tous les processus avec leurs états actuels
     */
    getProcesses(): Observable<Process[]> {
        return this.processesSubject.asObservable();
    }

    /**
     * Récupère un processus spécifique par son ID
     */
    getProcessById(id: string): Process | undefined {
        return this.mockData.find(process => process.id === id);
    }

    /**
     * Récupère tous les processus d'un type spécifique
     */
    getProcessesByType(type: ProcessType): Process[] {
        return this.mockData.filter(process => process.type === type);
    }

    /**
     * Sélectionne un processus pour l'affichage détaillé
     */
    selectProcess(process: Process | undefined): void {
        this.selectedProcessSubject.next(process);
    }

    /**
     * Observe les changements du processus sélectionné
     */
    getSelectedProcess(): Observable<Process | undefined> {
        return this.selectedProcessSubject.asObservable();
    }

    // === LOGIQUE MÉTIER POUR LA GESTION DES ÉTATS ===

    /**
     * Met à jour le statut d'une étape avec toute la logique métier associée
     * Implémente les règles de comportement du timeline réactif
     */
    updateStepStatus(processId: string, stepId: string, status: StepStatus): void {
        const processIndex = this.mockData.findIndex(p => p.id === processId);
        if (processIndex === -1) return;

        // Créer une copie profonde du processus pour éviter les mutations
        const process = this.deepCloneProcess(this.mockData[processIndex]);
        const stepIndex = process.steps.findIndex(s => s.id === stepId);
        if (stepIndex === -1) return;

        // Appliquer le nouveau statut à l'étape
        process.steps[stepIndex].status = status;

        // Gérer la date de complétion
        if (status === StepStatus.COMPLETED) {
            process.steps[stepIndex].completionDate = new Date();
        } else {
            process.steps[stepIndex].completionDate = undefined;
        }

        // Appliquer la logique métier pour les étapes suivantes
        this.applyBusinessLogicToSubsequentSteps(process, stepIndex, status);

        // Mettre à jour les dates du processus
        process.updatedAt = new Date();

        // Remplacer le processus dans la base de données
        this.mockData[processIndex] = process;

        // Notifier tous les observateurs
        this.processesSubject.next([...this.mockData]);

        // Mettre à jour le processus sélectionné si nécessaire
        const selectedProcess = this.selectedProcessSubject.value;
        if (selectedProcess && selectedProcess.id === processId) {
            this.selectedProcessSubject.next({ ...process });
        }
    }

    /**
     * Applique la logique métier aux étapes suivantes selon les règles définies
     */
    private applyBusinessLogicToSubsequentSteps(process: Process, currentStepIndex: number, currentStatus: StepStatus): void {
        const subsequentSteps = process.steps.slice(currentStepIndex + 1);

        if (currentStatus === StepStatus.COMPLETED) {
            // Règle: Si une étape est complétée, toutes les étapes suivantes deviennent "En cours"
            subsequentSteps.forEach(step => {
                step.status = StepStatus.IN_PROGRESS;
                step.completionDate = undefined;
            });
        } else if (currentStatus === StepStatus.BLOCKED || currentStatus === StepStatus.CANCELLED) {
            // Règle: Si une étape est bloquée ou annulée, toutes les étapes suivantes sont bloquées
            subsequentSteps.forEach(step => {
                step.status = StepStatus.BLOCKED;
                step.completionDate = undefined;
            });
        } else if (currentStatus === StepStatus.IN_PROGRESS) {
            // Règle: Si une étape est en cours, les étapes suivantes restent "Non commencées"
            subsequentSteps.forEach(step => {
                if (step.status !== StepStatus.COMPLETED) {
                    step.status = StepStatus.NOT_STARTED;
                    step.completionDate = undefined;
                }
            });
        } else if (currentStatus === StepStatus.NOT_STARTED) {
            // Règle: Si une étape redevient "Non commencée", les étapes suivantes le deviennent aussi
            subsequentSteps.forEach(step => {
                step.status = StepStatus.NOT_STARTED;
                step.completionDate = undefined;
            });
        }
    }

    /**
     * Crée une copie profonde d'un processus pour éviter les mutations
     */
    private deepCloneProcess(process: Process): Process {
        return {
            ...process,
            steps: process.steps.map(step => ({ ...step })),
            createdAt: new Date(process.createdAt),
            updatedAt: new Date(process.updatedAt)
        };
    }

    // === GÉNÉRATION DE NOUVEAUX PROCESSUS ===

    /**
     * Crée un nouveau processus avec tous les paramètres par défaut appropriés
     */
    createNewProcess(type: ProcessType): Process {
        this.processCounters[type]++;
        const newNumber = this.processCounters[type];

        const prefix = this.getProcessPrefix(type);
        const declarationNumber = `${prefix}-2025-${newNumber.toString().padStart(4, '0')}`;

        // Génère un NINA aléatoire de 15 chiffres
        const nina = this.generateRandomNina();

        const steps = this.createStepsForProcessType(type);

        const newProcess: Process = {
            id: `${type.toLowerCase()}-${newNumber.toString().padStart(3, '0')}`,
            type,
            declarationNumber,
            nina,
            steps,
            createdAt: new Date(),
            updatedAt: new Date()
        };

        this.mockData.push(newProcess);
        this.processesSubject.next([...this.mockData]);

        return newProcess;
    }

    /**
     * Obtient le préfixe approprié pour le numéro de déclaration
     */
    private getProcessPrefix(type: ProcessType): string {
        const prefixes = {
            [ProcessType.BIRTH]: 'N',
            [ProcessType.MARRIAGE]: 'M',
            [ProcessType.DEATH]: 'D'
        };
        return prefixes[type];
    }

    /**
     * Génère un NINA aléatoire de 15 chiffres
     */
    private generateRandomNina(): string {
        return Array.from({ length: 15 }, () => Math.floor(Math.random() * 10)).join('');
    }

    /**
     * Crée les étapes par défaut pour un type de processus donné
     */
    private createStepsForProcessType(type: ProcessType): ProcessStep[] {
        const timestamp = new Date().getTime();

        const stepsTemplates = {
            [ProcessType.BIRTH]: [
                { label: 'Enregistrement de naissance', icon: 'app_registration' },
                { label: 'Déclaration de naissance', icon: 'description' },
                { label: 'Établissement de l\'acte', icon: 'gavel' },
                { label: 'Remise de l\'acte', icon: 'assignment_turned_in' }
            ],
            [ProcessType.MARRIAGE]: [
                { label: 'Déclaration de mariage', icon: 'favorite' },
                { label: 'Publication de mariage', icon: 'campaign' },
                { label: 'Enquêtes prénuptiales', icon: 'find_in_page' },
                { label: 'Célébration et Remise de l\'acte', icon: 'celebration' }
            ],
            [ProcessType.DEATH]: [
                { label: 'Certificat de décès', icon: 'medical_services' },
                { label: 'Déclaration de décès', icon: 'description' },
                { label: 'Établissement de l\'acte', icon: 'gavel' },
                { label: 'Remise de l\'acte', icon: 'assignment_turned_in' }
            ]
        };

        const templates = stepsTemplates[type];
        const prefix = type.charAt(0).toLowerCase();

        return templates.map((template, index) => ({
            id: `${prefix}${index + 1}-${timestamp}`,
            order: index + 1,
            label: template.label,
            icon: template.icon,
            status: StepStatus.NOT_STARTED,
            completionDate: undefined
        }));
    }

    // === MÉTHODES D'ANALYSE ET DE REPORTING ===

    /**
     * Calcule les statistiques pour un type de processus
     */
    getProcessStatistics(type: ProcessType): {
        total: number;
        completed: number;
        inProgress: number;
        blocked: number;
        notStarted: number;
    } {
        const processes = this.getProcessesByType(type);

        const stats = {
            total: processes.length,
            completed: 0,
            inProgress: 0,
            blocked: 0,
            notStarted: 0
        };

        processes.forEach(process => {
            const allCompleted = process.steps.every(step => step.status === StepStatus.COMPLETED);
            const hasBlocked = process.steps.some(step => step.status === StepStatus.BLOCKED || step.status === StepStatus.CANCELLED);
            const hasInProgress = process.steps.some(step => step.status === StepStatus.IN_PROGRESS);
            const allNotStarted = process.steps.every(step => step.status === StepStatus.NOT_STARTED);

            if (allCompleted) {
                stats.completed++;
            } else if (hasBlocked) {
                stats.blocked++;
            } else if (hasInProgress) {
                stats.inProgress++;
            } else if (allNotStarted) {
                stats.notStarted++;
            }
        });

        return stats;
    }

    /**
     * Vérifie les règles de validation métier pour un processus
     */
    validateProcessBusinessRules(process: Process): {
        isValid: boolean;
        violations: string[];
    } {
        const violations: string[] = [];
        let previousStepCompleted = true;

        for (let i = 0; i < process.steps.length; i++) {
            const step = process.steps[i];

            // Règle: Une étape ne peut être complétée que si l'étape précédente l'est
            if (step.status === StepStatus.COMPLETED && !previousStepCompleted) {
                violations.push(`L'étape "${step.label}" ne peut être complétée car l'étape précédente n'est pas terminée`);
            }

            // Règle: Si une étape est bloquée, toutes les suivantes doivent être bloquées
            if (step.status === StepStatus.BLOCKED) {
                for (let j = i + 1; j < process.steps.length; j++) {
                    const nextStep = process.steps[j];
                    if (nextStep.status !== StepStatus.BLOCKED) {
                        violations.push(`L'étape "${nextStep.label}" devrait être bloquée car une étape précédente est bloquée`);
                    }
                }
                break;
            }

            previousStepCompleted = step.status === StepStatus.COMPLETED;
        }

        return {
            isValid: violations.length === 0,
            violations
        };
    }

    // === MÉTHODES DE SIMULATION ET DE TEST ===

    /**
     * Simule la progression automatique d'un processus (pour les tests)
     */
    simulateProcessProgression(processId: string, targetStepIndex: number): void {
        const process = this.getProcessById(processId);
        if (!process) return;

        for (let i = 0; i <= targetStepIndex; i++) {
            const step = process.steps[i];
            if (step.status === StepStatus.NOT_STARTED || step.status === StepStatus.IN_PROGRESS) {
                // Simule un délai entre les étapes
                setTimeout(() => {
                    this.updateStepStatus(processId, step.id, StepStatus.COMPLETED);
                }, i * 1000);
            }
        }
    }

    /**
     * Remet à zéro un processus (pour les tests)
     */
    resetProcess(processId: string): void {
        const processIndex = this.mockData.findIndex(p => p.id === processId);
        if (processIndex === -1) return;

        const process = this.deepCloneProcess(this.mockData[processIndex]);

        process.steps.forEach(step => {
            step.status = StepStatus.NOT_STARTED;
            step.completionDate = undefined;
        });

        process.updatedAt = new Date();
        this.mockData[processIndex] = process;

        this.processesSubject.next([...this.mockData]);

        if (this.selectedProcessSubject.value?.id === processId) {
            this.selectedProcessSubject.next({ ...process });
        }
    }
}